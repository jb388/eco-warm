

### 

library(tidyverse)
library(nlme)
library(piecewiseSEM)
library(broom)
library(viridis)
library(broom.mixed)
library(lmPerm)
library(influence.ME)

rm(list=ls()) 

## set working directory

## 13CO2 pulse labeling C allocation 

## load the sheet one containing C allocation data

data <- read_excel("Data_all.xlsx",  # nolint
                   sheet = "13C_allocation") 


# Plot: Plot number 
# warming_temperature: Mean warming temperature above ambient
# N.addition: N fertilization treatment with NH4NO3, 0 and 50 kg/Hectare yr
# Day: Day from 13CO2 pulse labeling, Day 0: day of pulse labeling
# Rel_: Amount of labelled 13C remaining in the plant soil system.
# MRT: Mean residence times

### Mean residence times ###

## MRT leaf
data%>%
  distinct(plot, .keep_all = TRUE) %>%
  ggplot()+
  geom_point(aes(warming_temperature,Leaf_MRT, color = warming_temperature, shape = as.factor(N.addition)))+
  scale_colour_gradient(low = "black", high = "red", na.value = NA)+
  geom_smooth(aes(warming_temperature,Leaf_MRT), method = 'lm')+
  scale_shape_manual(values=c(16,2))+
  theme_bw()+
  theme(axis.text = element_text(size = 12))+
  theme(strip.background =element_rect(fill="white"),strip.text.x = element_text(size = 10, colour = "black"))+
  theme(panel.spacing.x=unit(0.2, "lines"),strip.text.y = element_blank(),
        panel.spacing.y=unit(0, "lines"),panel.grid.major = element_blank(), 
        panel.grid.minor = element_blank(),strip.text = element_text(colour = 'black'))

### MRT Soil respiration
data%>%
  distinct(plot, .keep_all = TRUE) %>%
  ggplot()+
  geom_point(aes(warming_temperature,SR_MRT, color = warming_temperature, shape = as.factor(N.addition)))+
  scale_colour_gradient(low = "black", high = "red", na.value = NA)+
  geom_smooth(aes(warming_temperature,SR_MRT, linetype = as.factor(N.addition)), method = 'lm')+
  scale_shape_manual(values=c(16,2))+
  theme_bw()+
  theme(axis.text = element_text(size = 12))+
  theme(strip.background =element_rect(fill="white"),strip.text.x = element_text(size = 10, colour = "black"))+
  theme(panel.spacing.x=unit(0.2, "lines"),strip.text.y = element_blank(),
        panel.spacing.y=unit(0, "lines"),panel.grid.major = element_blank(), 
        panel.grid.minor = element_blank(),strip.text = element_text(colour = 'black'))

### MRT stats

## Soil respiration
summary(lm(SR_MRT ~ warming_temperature + as.factor(N.addition), data = data%>%
             distinct(plot, .keep_all = TRUE)))
shapiro.test(resid(lm(SR_MRT ~ warming_temperature + as.factor(N.addition), data = data%>%
                  distinct(plot, .keep_all = TRUE))))

## leaf
summary(lm(Leaf_MRT ~ warming_temperature + as.factor(N.addition), data = data%>%
             distinct(plot, .keep_all = TRUE)))
shapiro.test(resid(lm(Leaf_MRT ~ warming_temperature + as.factor(N.addition), data = data%>%
                        distinct(plot, .keep_all = TRUE))))





### C allocation ###

## Figure

data %>%
  select(plot,warming_temperature,N.addition,Day,Rel_Leaf,Rel_Root,Rel_DOC,Rel_Cmic,Rel_SR)%>%
  pivot_longer(Rel_Leaf:Rel_SR) %>%
  mutate(name = factor(name, levels=c("Rel_Leaf", "Rel_Root", "Rel_DOC", "Rel_Cmic", "Rel_SR")))%>%
  mutate(warming = ifelse(warming_temperature < 4, 'low', 'high'))%>%
  unite(id, c(N.addition,warming), sep='', remove=FALSE)%>%
  mutate(id = as.factor(id))%>%
  ggplot(aes(Day,value,shape = as.factor(N.addition),color = warming_temperature))+
  geom_point(position=position_dodge(width = 0.2))+  theme_bw()+
  geom_smooth(aes(group =id, linetype = id ),se = FALSE, span = 0.7)+
  facet_grid(name~., scales='free_y') +
  #scale_color_viridis(option="turbo")+
  scale_colour_gradient(low = "black", high = "red", na.value = NA)+
  scale_shape_manual(values=c(16,2))+
  scale_x_continuous(breaks = c(0,1,3,6,10))+
  coord_cartesian(xlim = c(0,10.5))+
  scale_linetype_manual(values=c("solid","longdash","dotted","dashed"))+
  theme_bw()+
  theme(axis.text = element_text(size = 12))+
  theme(strip.background =element_rect(fill="white"),strip.text.x = element_text(size = 10, colour = "black"))+
  theme(panel.spacing.x=unit(0.2, "lines"),strip.text.y = element_blank(),
        panel.spacing.y=unit(0, "lines"),panel.grid.major = element_blank(), 
        panel.grid.minor = element_blank(),strip.text = element_text(colour = 'black'))


## C allocation stats
# log transformation of response variables
# log correction is to get normality of residuals
Leaf_mod = lme(log(Rel_Leaf) ~ warming_temperature + N.addition, na.action = na.omit,
              random = ~1|Day, method = 'REML' ,data = filter(data, Day > 0))
summary(Leaf_mod)
shapiro.test(Leaf_mod$residuals)

Root_mod = lme(log(Rel_Root) ~ warming_temperature + N.addition, na.action = na.omit,
            random = ~1|Day, method = 'REML' ,data = filter(data, Day > 0))
summary(Root_mod)
shapiro.test(Root_mod$residuals)

DOC_mod = lme(log(Rel_DOC+0.005) ~ warming_temperature + N.addition, na.action = na.omit,
               random = ~1|Day, method = 'REML' ,data = filter(data, Day > 0))
summary(DOC_mod)
shapiro.test(DOC_mod$residuals)


Cmic_mod = lme(log(Rel_Cmic + 0.005) ~ warming_temperature + N.addition, na.action = na.omit,
               random = ~1|Day, method = 'REML' ,data = filter(data, Day > 0))
summary(Cmic_mod)
shapiro.test(Cmic_mod$residuals)


SR_mod = lme(log(Rel_SR) ~ warming_temperature + N.addition, na.action = na.omit,
             random = ~1|Day, method = 'REML' ,data = data)
summary(SR_mod)
shapiro.test(SR_mod$residuals)


#### Structural equation modelling  ####

# load the soil N, plant N and Microbial biomass (MBC + MBN) sheets from the data file

library(piecewiseSEM)

SEM_model <- psem(
  
  ### effects on plant and soil N
  
  lme(MB ~ Warm  , na.action = na.omit,
      random = ~1|Day, method = 'REML' ,data ),
  lme(DON ~ Warm + MB, na.action = na.omit,
      random = ~1|Day, method = 'REML' ,data ),
  lme(NH4.N ~ Warm+ N.addition *MB, na.action = na.omit,
      random = ~1|Day, method = 'REML' ,data ),
  lme(NO3.N ~   MB*N.addition     , na.action = na.omit,
      random = ~1|Day, method = 'REML' ,data ),
  lme(AB_CN ~ NH4.N*N.addition + Warm , na.action = na.omit,
      random = ~1|Day, method = 'REML' ,data ),
  

  ### effects on C allocation
  lme(Rel_Leaf ~   NH4.N + AB_CN , na.action = na.omit,
      random = ~1|Day, method = 'REML' ,data = filter(data, Day > 0)),
  lme(Rel_Root ~ NH4.N* N.addition+Warm  + AB_CN, na.action = na.omit,
      random = ~1|Day, method = 'REML' ,data = filter(data, Day > 0)),
  lme(Rel_DOC ~    Warm+N.addition  + MB +AB_CN   , na.action = na.omit,
      random = ~1|Day, method = 'REML' ,data = filter(data, Day > 0)),
  lme(Rel_Cmic ~  Warm+Rel_DOC, na.action = na.omit,
      random = ~1|Day, method = 'REML' ,data = filter(data, Day > 0)),
  lme(Rel_SR ~  Warm+  MB  , na.action = na.omit,
      random = ~1|Day, method = 'REML' ,data = filter(data, Day > 0))
)

summary(SEM_model, standardized  = TRUE)



### Ecosystem CO2 fluxes 

## read the ecosystem fluxes sheet from the data file

### Figure, apply y to NEE, GPP, ER
flux %>%
  ggplot(aes(x = warming_temperature, y = NEE, color = warming_temperature,shape = as.factor(N.addition)))+
  stat_summary(fun.y = mean, geom = "point", size =2, aes()) + 
  stat_summary(fun.data = mean_se, geom = "errorbar", size =1)+
  geom_smooth(aes(linetype = as.factor(N.addition)),alpha=0.3,color = 'black', method = lm)+
  scale_colour_gradient(low = "black", high = "red", na.value = NA)+
  scale_shape_manual(values=c(16,2))+
  scale_x_continuous(breaks = c(0,2,4,6,8,10))+
  coord_cartesian(xlim = c(0,9))+
  theme_bw()+
  theme(axis.text = element_text(size = 12))+
  theme(panel.spacing.x=unit(0.2, "lines"),strip.text.y = element_blank(),
        panel.spacing.y=unit(0, "lines"),panel.grid.major = element_blank(), 
        panel.grid.minor = element_blank(),strip.text = element_text(colour = 'black'))


# log correction is to get normality of residuals
NEE_mod = lme(log(NEE+10) ~ warming_temperature*N.addition, random=~1|DOY,na.action = na.omit, data=flux)
summary(NEE_mod)
shapiro.test(resid(NEE_mod))

GPP_mod = lme(log(GPP+10) ~ warming_temperature*N.addition, random=~1|DOY,na.action = na.omit, data=flux)
summary(GPP_mod)
shapiro.test(resid(GPP_mod))

ER_mod = lme(log(ER) ~ warming_temperature+N.addition, random=~1|DOY, na.action = na.omit, data=flux)
summary(ER_mod)
shapiro.test(resid(ER_mod))


### read SR sheet
SR = data <- read_excel("Data_all.xlsx", 
                        sheet = "13C_allocation")  %>%
  left_join(select(flux,plot,warming_temperature,N.addition)%>% distinct(plot,.keep_all = T) )

SR %>%
  ggplot(aes(x = warming_temperature, y = SR, color = warming_temperature,shape = as.factor(N.addition)))+
  stat_summary(fun.y = mean, geom = "point", size =2, aes()) + 
  stat_summary(fun.data = mean_se, geom = "errorbar", size =1)+
  geom_smooth(aes(linetype = as.factor(N.addition)),alpha=0.3,color = 'black', method = lm)+
  scale_colour_gradient(low = "black", high = "red", na.value = NA)+
  scale_shape_manual(values=c(16,2))+
  scale_x_continuous(breaks = c(0,2,4,6,8,10))+
  coord_cartesian(xlim = c(0,9))+
  theme_bw()+
  theme(axis.text = element_text(size = 12))+
  theme(panel.spacing.x=unit(0.2, "lines"),strip.text.y = element_blank(),
        panel.spacing.y=unit(0, "lines"),panel.grid.major = element_blank(), 
        panel.grid.minor = element_blank(),strip.text = element_text(colour = 'black'))

SR_mod = lme(SR ~ warming_temperature+N.addition, random=~1|Day, na.action = na.omit, data=SR)
summary(SR_mod)
shapiro.test(resid(SR_mod))



### Time series analysis ####

### load the time series analysis sheet

## cross correlation and time lag analysis  for Soil repsiration

datalist = list()

## loop for different lead and lags

for(i in 1:11){
  
  l = i-6
  settransform(data, SR2 = flag(SR, l,Plot,DOY))## change SR, resid
  
  it = data%>%
    group_by(Plot)%>%
    do(mod = tidy(lm(SR2 ~ PAR +ST+SWC, data = .)))%>%
    unnest(mod)%>%
    mutate(Lag = l)
  
  datalist[[i]] <- it
  
}
chall <- do.call(rbind,datalist)

str(chall)
chall2 = chall%>%
  filter(term != '(Intercept)')%>%
  filter(term != 'SWC')%>%
  rename(treatment =Plot)%>%
  left_join(plot, by = 'treatment')%>%
  arrange(treatment,Lag)%>%
  mutate(sig = ifelse(p.value < 0.05, "yes",'not'))%>%
  ggplot()+
  geom_point(aes(Lag,statistic, color = as.numeric(Temperature), shape = sig, size = 0.3))+
  geom_line(aes(Lag,statistic, color = as.numeric(Temperature), group = treatment))+
  facet_wrap(N.Addition~term)+
  scale_shape_manual(values=c(1, 16))+
  scale_colour_gradient(name = "category",
                        low = "blue", high = "red")+
  theme_bw()
chall2

##### Cross correlation for SR13C #####

datalist = list()

for(i in 1:11){
  
  l = i-6
  settransform(data, SR13C2 = flag(SR13C , l,Plot,DOY))## change SR, resid
  
  it = data%>%
    group_by(Plot)%>%
    do(mod = tidy(lm(SR13C2 ~ PAR +ST+SWC, data = .)))%>%
    unnest(mod)%>%
    mutate(Lag = l)
  
  datalist[[i]] <- it
  
}
challSR13 <- do.call(rbind,datalist)

str(challSR13)
challSR132 = challSR13%>%
  filter(term != '(Intercept)')%>%
  filter(term != 'SWC')%>%
  rename(treatment =Plot)%>%
  left_join(plot, by = 'treatment')%>%
  arrange(treatment,Lag)%>%
  ggplot()+
  geom_point(aes(Lag,statistic, color = as.numeric(Temperature), shape = sig, size = 0.3))+
  geom_line(aes(Lag,statistic, color = as.numeric(Temperature), group = treatment))+
  facet_wrap(N.Addition~term)+
  scale_shape_manual(values=c(1, 16))+
  scale_colour_gradient(name = "category",
                        low = "blue", high = "red")+
  theme_bw()

############


